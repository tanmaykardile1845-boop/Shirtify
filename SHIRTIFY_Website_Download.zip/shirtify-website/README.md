# SHIRTIFY – automatic payment + order delivery

After a customer pays, the server verifies the payment with Razorpay and sends the order
(name, phone, address, items, amount, payment ID and any custom artwork file) to YOUR Telegram.
The customer only sees "Payment verified".

## One-time setup
1. **Razorpay** (razorpay.com): create an account, complete KYC, then Settings → API Keys → generate keys.
   Make sure payment capture is **automatic** (Settings → Payment Capture) and UPI is enabled.
2. **Telegram**: open @BotFather → /newbot → copy the bot token. Send any message to your new bot,
   then open `https://api.telegram.org/bot<TOKEN>/getUpdates` and copy `"chat":{"id": ...}` — that is your chat id.
3. **Host the server** (needs Node 18+; e.g. Render.com or Railway → New Web Service → upload this folder,
   start command `node server.js`). Add the variables from `.env.example` in the host's settings.
   Your site is then served from the same address.
4. **Webhook** (safety net so orders arrive even if the customer closes the tab after paying):
   Razorpay → Settings → Webhooks → Add: URL `https://YOUR-SITE/api/webhook`, secret = RAZORPAY_WEBHOOK_SECRET,
   events `payment.captured` and `order.paid`.
5. Test with Razorpay **test keys** first (rzp_test_...), then switch to live keys.

## Cash on Delivery
Customers now choose **Pay online** or **Cash on delivery** after entering their details.
COD orders are sent to your Telegram marked "NOT PAID YET" with the amount to collect. COD only needs the
Telegram settings (no Razorpay). Each device is limited to 8 COD orders per hour to reduce fake orders.
Custom T-shirts on COD: the price is confirmed with the customer by you; nothing is collected upfront.

## Notes
- Prices are set in `server.js` (PRODUCTS) – change them there, and in `index.html` for display.
- Custom T-shirts: customer pays an advance (CUSTOM_ADVANCE, default ₹200 each); you confirm the final price with them.
- If the server isn't running (e.g. plain static hosting), the site automatically falls back to the manual
  UPI QR + transaction ID + WhatsApp flow.
- `upi-qr.png` is your UPI QR with the SHIRTIFY logo in the centre (for print / the manual fallback).


## Customer accounts
Customers can create a free SHIRTIFY account (name, email, phone, password) from the **Account** button in the header.
- Passwords are hashed with scrypt and stored in `data/users.json` (never plain text).
- Logged-in customers get their name and phone auto-filled at checkout.
- Accounts require the Node server to be running (`node server.js`).
- **Continue with Google**: set `GOOGLE_CLIENT_ID` (OAuth 2.0 Web Client ID from Google Cloud Console).
  Add your site URL under *Authorized JavaScript origins*. The button appears automatically in the
  login / sign-up modal when the variable is set. New Google users are created without a password;
  existing email accounts can also sign in with Google.


### Continue with Apple
- Set `APPLE_CLIENT_ID` to your Apple **Services ID** (not your app's bundle ID).
- In Apple Developer, enable **Sign in with Apple** for the Services ID, configure your primary App ID,
  add your website domain, and set the return URL to your exact HTTPS site origin (for example `https://your-domain.com`).
- Install dependencies with `npm install` and restart the Node server. The Apple button appears when configured.
- Apple sign-in is verified on the server using Apple's published signing keys. Apple may provide the customer's name only on their first authorization; otherwise SHIRTIFY uses the email prefix as the account display name.
- Google sign-in remains available by setting `GOOGLE_CLIENT_ID` as described above. Both social sign-in buttons require the Node server; they do not work on static-only hosting.
