// SHIRTIFY order server — zero dependencies, needs Node 18+.
// Flow: customer pays via Razorpay -> server VERIFIES the payment -> order is sent to the OWNER on Telegram.
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const env = process.env;
const PORT = env.PORT || 3000;
const KEY_ID = env.RAZORPAY_KEY_ID || '';
const KEY_SECRET = env.RAZORPAY_KEY_SECRET || '';
const WEBHOOK_SECRET = env.RAZORPAY_WEBHOOK_SECRET || '';
const TG_TOKEN = env.TELEGRAM_BOT_TOKEN || '';
const TG_CHAT = env.TELEGRAM_CHAT_ID || '';
const RZP_API = env.RAZORPAY_API_BASE || 'https://api.razorpay.com';
const TG_API = env.TELEGRAM_API_BASE || 'https://api.telegram.org';
const DATA_DIR = env.DATA_DIR || path.join(__dirname, 'data');
const CUSTOM_ADVANCE = Number(env.CUSTOM_ADVANCE || 200); // ₹ per custom T-shirt, paid upfront
const GOOGLE_CLIENT_ID = env.GOOGLE_CLIENT_ID || ''; // Google OAuth 2.0 Web Client ID
const APPLE_CLIENT_ID = env.APPLE_CLIENT_ID || ''; // Apple Services ID (Sign in with Apple)

// Prices live on the SERVER so customers cannot change them in the browser.
const PRODUCTS = {
  1: { name: 'Racing Club 23', price: 799 },
  2: { name: 'Mountain Vintage', price: 799 },
  3: { name: 'Silver Flame', price: 799 },
  4: { name: 'Botanical Lines', price: 799 },
  5: { name: 'Wave of Japan', price: 799 },
  6: { name: 'Good Mood', price: 799 },
};
const SIZES = ['S', 'M', 'L', 'XL', 'XXL'];
const FILE_TYPES = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp', 'application/pdf': 'pdf' };
const MAX_FILE = 8 * 1024 * 1024;

fs.mkdirSync(path.join(DATA_DIR, 'uploads'), { recursive: true });
const DB = path.join(DATA_DIR, 'orders.json');
let orders = {};
try { orders = JSON.parse(fs.readFileSync(DB, 'utf8')); } catch (e) { /* first run */ }
const save = () => fs.writeFileSync(DB, JSON.stringify(orders, null, 1));

const USERS_DB = path.join(DATA_DIR, 'users.json');
let users = {};
try { users = JSON.parse(fs.readFileSync(USERS_DB, 'utf8')); } catch (e) { /* first run */ }
const saveUsers = () => fs.writeFileSync(USERS_DB, JSON.stringify(users, null, 1));

// Simple session store: token -> { email, exp }
const sessions = new Map();
const SESSION_TTL = 30 * 24 * 3600e3; // 30 days

function hashPassword(password, salt) {
  return new Promise((resolve, reject) => {
    crypto.scrypt(password, salt, 64, (err, key) => err ? reject(err) : resolve(key.toString('hex')));
  });
}
function newToken() { return crypto.randomBytes(32).toString('hex'); }
function getSession(req) {
  const h = req.headers['authorization'] || '';
  const m = h.match(/^Bearer\s+(.+)$/i);
  const token = m ? m[1].trim() : '';
  if (!token) return null;
  const s = sessions.get(token);
  if (!s || s.exp < Date.now()) { sessions.delete(token); return null; }
  return { token, ...s };
}


const gatewayReady = () => !!(KEY_ID && KEY_SECRET && TG_TOKEN && TG_CHAT);

// ---------- helpers ----------
const hmac = (secret, data) => crypto.createHmac('sha256', secret).update(data).digest('hex');
const safeEq = (a, b) => { a = Buffer.from(String(a)); b = Buffer.from(String(b)); return a.length === b.length && crypto.timingSafeEqual(a, b); };
const clean = (v, max = 300) => String(v == null ? '' : v).replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, max);

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', c => { size += c.length; if (size > limit) { reject(new Error('too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}
const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };

const hits = new Map(); // tiny per-IP rate limit for order creation
function limited(ip, max) {
  const now = Date.now(), arr = (hits.get(ip) || []).filter(t => now - t < 3600e3);
  arr.push(now); hits.set(ip, arr); return arr.length > max;
}

// ---------- Telegram (owner notification) ----------
async function tg(method, body) {
  const r = await fetch(`${TG_API}/bot${TG_TOKEN}/${method}`, body instanceof FormData
    ? { method: 'POST', body }
    : { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  if (!r.ok) throw new Error(`Telegram ${method} failed: ${r.status} ${await r.text()}`);
}

function orderText(o) {
  const cod = o.method === 'cod';
  const lines = o.items.map((x, i) => x.type === 'ready'
    ? `${i + 1}. ${x.name} | Size ${x.size} | Qty ${x.qty} | ₹${x.price * x.qty}`
    : `${i + 1}. CUSTOM T-shirt | Size ${x.size} | Qty ${x.qty} | ${x.fit}, ${x.colour} | ${cod ? 'Price to be confirmed with customer' : `Advance paid ₹${CUSTOM_ADVANCE * x.qty} (final price to be confirmed)`}\n   Notes: ${x.notes || '-'}\n   Artwork: ${x.fileName || '-'}`);
  const head = cod ? `📦 NEW CASH ON DELIVERY ORDER ${o.ref}` : `✅ NEW PAID ORDER ${o.ref}`;
  const foot = cod
    ? `PAYMENT: CASH ON DELIVERY — NOT PAID YET\nCollect on delivery: ₹${o.amount / 100}${o.items.some(x => x.type === 'custom') ? ' for ready-made items + custom T-shirt price (confirm with customer)' : ''}`
    : `PAID: ₹${o.amount / 100} (verified)\nPayment ID: ${o.paymentId}`;
  return `${head}\n\nCustomer: ${o.customer.name}\nPhone: ${o.customer.phone}\nAddress: ${o.customer.address}\n\n${lines.join('\n')}\n\n${foot}`;
}

async function notifyOwner(o) {
  await tg('sendMessage', { chat_id: TG_CHAT, text: orderText(o) });
  for (const x of o.items) {
    if (x.type === 'custom' && x.filePath && fs.existsSync(x.filePath)) {
      const form = new FormData();
      form.append('chat_id', TG_CHAT);
      form.append('caption', `Artwork for order ${o.ref} (size ${x.size}, qty ${x.qty})`);
      form.append('document', new Blob([fs.readFileSync(x.filePath)]), x.fileName || path.basename(x.filePath));
      await tg('sendDocument', form);
    }
  }
}

// Marks an order paid (idempotent) and makes sure the owner is notified exactly once.
async function deliver(o) {
  if (!o.notified) {
    try { await notifyOwner(o); o.notified = true; save(); }
    catch (e) { console.error('Owner notification failed, will retry:', e.message); }
  }
}
async function markPaid(o, paymentId) {
  if (o.status !== 'paid') { o.status = 'paid'; o.paymentId = paymentId; o.paidAt = new Date().toISOString(); save(); }
  await deliver(o);
}
setInterval(() => { // retry any paid order whose notification failed
  Object.values(orders).filter(o => (o.status === 'paid' || o.status === 'cod') && !o.notified).forEach(o => deliver(o));
}, 60000);

// ---------- order creation ----------
function buildOrder(body, cod = false) {
  const c = body.customer || {};
  const customer = { name: clean(c.name, 100), phone: clean(c.phone, 20), address: clean(c.address, 400) };
  if (!customer.name || !/^[0-9+() -]{10,16}$/.test(customer.phone) || !customer.address) throw new Error('Please fill in name, phone and address correctly.');
  if (!Array.isArray(body.items) || !body.items.length || body.items.length > 20) throw new Error('Your bag is empty.');
  let total = 0; const items = []; const ref = 'SH' + Date.now().toString(36).toUpperCase() + crypto.randomBytes(2).toString('hex').toUpperCase();
  body.items.forEach((x, i) => {
    const qty = Number(x.qty), size = clean(x.size, 5);
    if (!Number.isInteger(qty) || qty < 1 || qty > 50 || !SIZES.includes(size)) throw new Error('Invalid item in bag.');
    if (x.type === 'ready') {
      const p = PRODUCTS[Number(x.id)]; if (!p) throw new Error('Unknown product.');
      items.push({ type: 'ready', id: Number(x.id), name: p.name, price: p.price, size, qty }); total += p.price * qty;
    } else if (x.type === 'custom') {
      const m = /^data:([\w/+.-]+);base64,(.+)$/.exec(x.fileData || '');
      if (!m || !FILE_TYPES[m[1]]) throw new Error('Custom design must be PNG, JPG, WEBP or PDF.');
      const buf = Buffer.from(m[2], 'base64'); if (!buf.length || buf.length > MAX_FILE) throw new Error('Design file must be under 8 MB.');
      const filePath = path.join(DATA_DIR, 'uploads', `${ref}-${i}.${FILE_TYPES[m[1]]}`); fs.writeFileSync(filePath, buf);
      items.push({ type: 'custom', size, qty, fit: clean(x.fit, 30), colour: clean(x.colour, 30), notes: clean(x.notes, 500), fileName: clean(x.fileName, 120), filePath });
      if (!cod) total += CUSTOM_ADVANCE * qty; // COD: custom price is confirmed later
    } else throw new Error('Invalid item type.');
  });
  return { ref, customer, items, amount: total * 100, status: 'created', notified: false, createdAt: new Date().toISOString() };
}

async function createOrder(body) {
  const o = buildOrder(body);
  const r = await fetch(`${RZP_API}/v1/orders`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Basic ' + Buffer.from(`${KEY_ID}:${KEY_SECRET}`).toString('base64') },
    body: JSON.stringify({ amount: o.amount, currency: 'INR', receipt: o.ref, notes: { ref: o.ref } }),
  });
  if (!r.ok) throw new Error('Could not start payment. Please try again.');
  o.rzpOrderId = (await r.json()).id;
  orders[o.ref] = o; save();
  return { ref: o.ref, orderId: o.rzpOrderId, amount: o.amount, keyId: KEY_ID };
}

async function createCod(body) {
  const o = buildOrder(body, true);
  o.method = 'cod'; o.status = 'cod';
  orders[o.ref] = o; save();
  await deliver(o); // if Telegram is down the order is kept and retried every minute
  return { ref: o.ref, amount: o.amount };
}

const findByRzp = id => Object.values(orders).find(o => o.rzpOrderId === id);

// ---------- routes ----------
async function handleApi(req, res, url) {
  if (url === '/api/config' && req.method === 'GET') return send(res, 200, {
    enabled: gatewayReady(),
    cod: !!(TG_TOKEN && TG_CHAT),
    customAdvance: CUSTOM_ADVANCE,
    googleClientId: GOOGLE_CLIENT_ID || null,
    appleClientId: APPLE_CLIENT_ID || null
  });

  if (url === '/api/create-order' && req.method === 'POST') {
    if (!gatewayReady()) return send(res, 503, { error: 'Online payment is not configured.' });
    if (limited(req.socket.remoteAddress, 20)) return send(res, 429, { error: 'Too many attempts. Please try later.' });
    try { return send(res, 200, await createOrder(JSON.parse((await readBody(req, 40 * 1024 * 1024)).toString()))); }
    catch (e) { return send(res, 400, { error: e.message }); }
  }

  if (url === '/api/create-cod-order' && req.method === 'POST') {
    if (!(TG_TOKEN && TG_CHAT)) return send(res, 503, { error: 'Cash on delivery is not available right now.' });
    if (limited('cod:' + req.socket.remoteAddress, 8)) return send(res, 429, { error: 'Too many orders from this device. Please try later.' });
    try { return send(res, 200, await createCod(JSON.parse((await readBody(req, 40 * 1024 * 1024)).toString()))); }
    catch (e) { return send(res, 400, { error: e.message }); }
  }

  if (url === '/api/verify' && req.method === 'POST') {
    try {
      const b = JSON.parse((await readBody(req, 100e3)).toString());
      const o = findByRzp(b.razorpay_order_id);
      if (!o || !KEY_SECRET || !safeEq(hmac(KEY_SECRET, `${b.razorpay_order_id}|${b.razorpay_payment_id}`), b.razorpay_signature))
        return send(res, 400, { error: 'Payment could not be verified.' });
      await markPaid(o, clean(b.razorpay_payment_id, 60));
      return send(res, 200, { ok: true, ref: o.ref });
    } catch (e) { return send(res, 400, { error: 'Bad request.' }); }
  }

  // Razorpay calls this by itself, so orders still arrive even if the customer closes the tab after paying.
  if (url === '/api/webhook' && req.method === 'POST') {
    const raw = await readBody(req, 1e6).catch(() => null);
    if (!raw || !WEBHOOK_SECRET || !safeEq(hmac(WEBHOOK_SECRET, raw), req.headers['x-razorpay-signature'] || '')) return send(res, 400, { error: 'bad signature' });
    try {
      const ev = JSON.parse(raw.toString()); const pay = ev.payload && ev.payload.payment && ev.payload.payment.entity;
      if (pay && (ev.event === 'payment.captured' || ev.event === 'order.paid')) {
        const o = findByRzp(pay.order_id);
        if (o && pay.amount === o.amount) await markPaid(o, pay.id);
      }
    } catch (e) { console.error('webhook error', e.message); }
    return send(res, 200, { ok: true });
  }

  // ---- Account (signup / login) ----
  if (url === '/api/signup' && req.method === 'POST') {
    if (limited('signup:' + req.socket.remoteAddress, 10)) return send(res, 429, { error: 'Too many attempts. Please try later.' });
    try {
      const b = JSON.parse((await readBody(req, 20e3)).toString());
      const name = clean(b.name, 80);
      const email = clean(b.email, 120).toLowerCase();
      const phone = clean(b.phone, 20);
      const password = String(b.password || '');
      if (!name || name.length < 2) return send(res, 400, { error: 'Please enter your full name.' });
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return send(res, 400, { error: 'Please enter a valid email.' });
      if (!/^[0-9+\-\s]{8,15}$/.test(phone)) return send(res, 400, { error: 'Please enter a valid phone number.' });
      if (password.length < 6) return send(res, 400, { error: 'Password must be at least 6 characters.' });
      if (users[email]) return send(res, 400, { error: 'An account with this email already exists. Please log in.' });
      const salt = crypto.randomBytes(16).toString('hex');
      const hash = await hashPassword(password, salt);
      users[email] = { name, email, phone, salt, hash, createdAt: new Date().toISOString(), orders: [] };
      saveUsers();
      const token = newToken();
      sessions.set(token, { email, exp: Date.now() + SESSION_TTL });
      return send(res, 200, { ok: true, token, user: { name, email, phone } });
    } catch (e) { return send(res, 400, { error: e.message || 'Could not create account.' }); }
  }

  if (url === '/api/login' && req.method === 'POST') {
    if (limited('login:' + req.socket.remoteAddress, 20)) return send(res, 429, { error: 'Too many attempts. Please try later.' });
    try {
      const b = JSON.parse((await readBody(req, 10e3)).toString());
      const email = clean(b.email, 120).toLowerCase();
      const password = String(b.password || '');
      const u = users[email];
      if (!u) return send(res, 400, { error: 'Invalid email or password.' });
      const hash = await hashPassword(password, u.salt);
      if (hash !== u.hash) return send(res, 400, { error: 'Invalid email or password.' });
      const token = newToken();
      sessions.set(token, { email, exp: Date.now() + SESSION_TTL });
      return send(res, 200, { ok: true, token, user: { name: u.name, email: u.email, phone: u.phone } });
    } catch (e) { return send(res, 400, { error: 'Could not log in.' }); }
  }

  if (url === '/api/me' && req.method === 'GET') {
    const s = getSession(req);
    if (!s) return send(res, 401, { error: 'Not logged in.' });
    const u = users[s.email];
    if (!u) return send(res, 401, { error: 'Not logged in.' });
    return send(res, 200, { user: { name: u.name, email: u.email, phone: u.phone } });
  }

  if (url === '/api/logout' && req.method === 'POST') {
    const s = getSession(req);
    if (s) sessions.delete(s.token);
    return send(res, 200, { ok: true });
  }

  // Sign in / sign up with Google (ID token from Google Identity Services)
  if (url === '/api/auth/google' && req.method === 'POST') {
    if (!GOOGLE_CLIENT_ID) return send(res, 503, { error: 'Google sign-in is not configured.' });
    if (limited('gauth:' + req.socket.remoteAddress, 30)) return send(res, 429, { error: 'Too many attempts. Please try later.' });
    try {
      const b = JSON.parse((await readBody(req, 10e3)).toString());
      const credential = String(b.credential || '').trim();
      if (!credential) return send(res, 400, { error: 'Missing Google credential.' });

      // Verify ID token with Google
      const ti = await fetch('https://oauth2.googleapis.com/tokeninfo?id_token=' + encodeURIComponent(credential));
      if (!ti.ok) return send(res, 400, { error: 'Invalid Google sign-in. Please try again.' });
      const payload = await ti.json();
      if (payload.aud !== GOOGLE_CLIENT_ID) return send(res, 400, { error: 'Invalid Google client.' });
      if (payload.email_verified !== 'true' && payload.email_verified !== true) {
        return send(res, 400, { error: 'Google email is not verified.' });
      }
      const email = clean(payload.email, 120).toLowerCase();
      const name = clean(payload.name || payload.given_name || email.split('@')[0], 80) || 'Customer';
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        return send(res, 400, { error: 'Could not read email from Google account.' });
      }

      let u = users[email];
      if (!u) {
        // Create account for new Google user (no password; phone optional)
        u = {
          name,
          email,
          phone: '',
          salt: '',
          hash: '',
          google: true,
          createdAt: new Date().toISOString(),
          orders: []
        };
        users[email] = u;
        saveUsers();
      } else {
        // Existing account: allow Google login (link if not already)
        if (!u.google) {
          u.google = true;
          if (!u.name) u.name = name;
          saveUsers();
        }
      }

      const token = newToken();
      sessions.set(token, { email, exp: Date.now() + SESSION_TTL });
      return send(res, 200, {
        ok: true,
        token,
        user: { name: u.name, email: u.email, phone: u.phone || '' }
      });
    } catch (e) {
      console.error('Google auth error', e.message);
      return send(res, 400, { error: 'Could not complete Google sign-in.' });
    }
  }

  // Sign in / sign up with Apple. Verify Apple's signed identity token server-side.
  if (url === '/api/auth/apple' && req.method === 'POST') {
    if (!APPLE_CLIENT_ID) return send(res, 503, { error: 'Apple sign-in is not configured.' });
    if (limited('aauth:' + req.socket.remoteAddress, 30)) return send(res, 429, { error: 'Too many attempts. Please try later.' });
    try {
      const b = JSON.parse((await readBody(req, 20e3)).toString());
      const identityToken = String(b.identityToken || '').trim();
      if (!identityToken) return send(res, 400, { error: 'Missing Apple identity token.' });
      const jwt = require('jsonwebtoken');
      const jwksClient = require('jwks-rsa');
      const client = jwksClient({ jwksUri: 'https://appleid.apple.com/auth/keys', cache: true, rateLimit: true });
      const getKey = (header, callback) => {
        if (!header.kid) return callback(new Error('Missing signing key id'));
        client.getSigningKey(header.kid, (err, key) => callback(err, key && (key.getPublicKey ? key.getPublicKey() : key.publicKey)));
      };
      const payload = await new Promise((resolve, reject) => jwt.verify(identityToken, getKey, {
        algorithms: ['RS256'], issuer: 'https://appleid.apple.com', audience: APPLE_CLIENT_ID
      }, (err, decoded) => err ? reject(err) : resolve(decoded)));
      if (!payload.email || (payload.email_verified !== true && payload.email_verified !== 'true')) {
        return send(res, 400, { error: 'Apple did not provide a verified email address.' });
      }
      const email = clean(payload.email, 120).toLowerCase();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return send(res, 400, { error: 'Could not read email from Apple account.' });
      const appleName = b.user && b.user.name ? [b.user.name.firstName, b.user.name.lastName].filter(Boolean).join(' ') : '';
      const name = clean(appleName || email.split('@')[0], 80) || 'Customer';
      let u = users[email];
      if (!u) {
        u = { name, email, phone: '', salt: '', hash: '', apple: true, createdAt: new Date().toISOString(), orders: [] };
        users[email] = u; saveUsers();
      } else if (!u.apple) {
        u.apple = true; if (!u.name) u.name = name; saveUsers();
      }
      const token = newToken();
      sessions.set(token, { email, exp: Date.now() + SESSION_TTL });
      return send(res, 200, { ok: true, token, user: { name: u.name, email: u.email, phone: u.phone || '' } });
    } catch (e) {
      console.error('Apple auth error', e.message);
      return send(res, 400, { error: 'Could not verify Apple sign-in. Please try again.' });
    }
  }

  return send(res, 404, { error: 'Not found' });
}

const MIME = { '.html': 'text/html; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.webp': 'image/webp' };
http.createServer(async (req, res) => {
  const url = req.url.split('?')[0];
  try {
    if (url.startsWith('/api/')) return await handleApi(req, res, url);
    // Only index.html and /assets are public — never server.js, .env or data/
    const file = url === '/' ? 'index.html' : (/^\/assets\/[\w.-]+$/.test(url) ? url.slice(1) : null);
    if (!file) { res.writeHead(404); return res.end('Not found'); }
    const data = fs.readFileSync(path.join(__dirname, file));
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' }); res.end(data);
  } catch (e) { res.writeHead(404); res.end('Not found'); }
}).listen(PORT, () => console.log(`SHIRTIFY running on port ${PORT} — online payments ${gatewayReady() ? 'ENABLED' : 'NOT configured (site falls back to manual QR)'}`));
