BUILD SHIRTIFY ADMIN APK WITH GITHUB ACTIONS

1. Sign in to https://github.com (create a free account if needed).
2. Create a NEW repository. Name it shirtify-admin-android. Choose Private if you prefer.
3. On the repository page choose Add file > Upload files.
4. Extract this ZIP on your computer. Open the extracted SHIRTIFY_Admin_Android_Studio_Project folder.
5. Upload the CONTENTS of that folder (including the hidden .github folder) into the repository root. Do not upload the outer folder itself.
   IMPORTANT: Ensure .github/workflows/build-apk.yml is included. If your file picker hides dot-folders, enable showing hidden files or create the workflow file manually using GitHub's Add file > Create new file option and the exact path .github/workflows/build-apk.yml.
6. Commit the files to the main branch.
7. Open the repository's Actions tab. Select "Build SHIRTIFY Admin APK" and click "Run workflow" if it has not started automatically.
8. Wait for the workflow to finish with a green check mark.
9. Open the completed workflow run. Under Artifacts, download SHIRTIFY-Admin-APK.
10. Extract the downloaded artifact ZIP. It contains app-debug.apk. Transfer it to your Android phone and tap it to install. You may need to allow installing apps from that source.

This creates an unsigned debug APK for testing/sideloading. It is not a Play Store release. Keep the GitHub repository private if you do not want the project source public. Never upload service-account JSON files, private API keys, or signing passwords.
