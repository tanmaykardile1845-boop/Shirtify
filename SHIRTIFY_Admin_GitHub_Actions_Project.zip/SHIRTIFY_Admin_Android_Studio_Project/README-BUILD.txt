SHIRTIFY ADMIN — ANDROID STUDIO PROJECT

This is an Android WebView app project for your live admin panel.
It opens https://shiirtify.netlify.app/admin.html inside its own app window.
It is not a browser shortcut.

BUILD THE APK
1. Install Android Studio on a Windows, Mac, or Linux computer.
2. Extract this ZIP.
3. In Android Studio choose File > Open and select the extracted folder (the folder containing settings.gradle).
4. Allow Android Studio to download/sync the Android Gradle plugin and SDK components.
5. Wait for Gradle Sync to finish.
6. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
7. When the build finishes, click the APK location shown by Android Studio. The APK is normally in app/build/outputs/apk/debug/app-debug.apk.
8. Transfer that APK to an Android phone and install it. The phone may ask you to allow installation from that file manager.

IMPORTANT
- Requires internet for Firebase, Cloudinary, and the live admin website.
- The minimum Android version configured is Android 6.0 (API 23).
- This project has not been compiled or device-tested in this environment.
- Google sign-in may be blocked by Google's embedded-WebView security policy. If that occurs, use email/password sign-in or we can change the app to launch Google's sign-in flow in the system browser.
- File selection is enabled for product image uploads.
- App package ID: com.shirtify.admin
